#ifndef _ADXL345_HPP_
#define _ADXL345_HPP_

#include "Arduino.h"
#include "iic_sensor.hpp"


void epo_adxl345_init();

void adxl435_power_off();






#endif
